<?php
@$host = "localhost";
@$db = "accs";
@$user = "root";
@$pass = "";
@$senha = "senha";
?>
